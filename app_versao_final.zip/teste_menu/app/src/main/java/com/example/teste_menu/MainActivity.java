package com.example.teste_menu;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawer;
    private NavigationView navigationView;
    private ActionBarDrawerToggle toggle;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        setupCustomMenu();

        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);
        navController = navHostFragment.getNavController();

        setupDrawerToggle(toolbar);

        setupNavigationController();
    }

    private void setupCustomMenu() {
        navigationView.removeAllViews();
        View customMenuView = LayoutInflater.from(this).inflate(R.layout.nav_custom_drawer, navigationView, false);
        navigationView.addView(customMenuView);

        LinearLayout cursosParent = customMenuView.findViewById(R.id.cursos_parent);
        LinearLayout cursosChildContainer = customMenuView.findViewById(R.id.cursos_child_container);
        LinearLayout estudanteParent = customMenuView.findViewById(R.id.estudante_parent);
        LinearLayout estudanteChildContainer = customMenuView.findViewById(R.id.estudante_child_container);

        cursosChildContainer.setVisibility(View.GONE);
        estudanteChildContainer.setVisibility(View.GONE);

        cursosParent.setOnClickListener(v -> toggleMenuSection(cursosChildContainer, estudanteChildContainer));
        estudanteParent.setOnClickListener(v -> toggleMenuSection(estudanteChildContainer, cursosChildContainer));

        setupMenuItems(customMenuView);
    }

    private void setupDrawerToggle(Toolbar toolbar) {
        toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        );
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void setupNavigationController() {
        navController.addOnDestinationChangedListener((controller, destination, arguments) -> {
            boolean isCourseFragment = isCourseDestination(destination.getId());

            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(isCourseFragment);

                if (isCourseFragment) {
                    toggle.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
                    drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
                    toggle.setDrawerIndicatorEnabled(false);
                    toggle.setToolbarNavigationClickListener(v -> handleBackNavigation());
                } else {
                    toggle.setHomeAsUpIndicator(null);
                    drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
                    toggle.setDrawerIndicatorEnabled(true);
                    toggle.setToolbarNavigationClickListener(null);
                }
            }
        });
    }

    private boolean isCourseDestination(int destinationId) {
        // Lista de todos os fragments de curso
        return destinationId == R.id.CursoAdmFragment ||
                destinationId == R.id.CursoAgroFragment ||
                destinationId == R.id.CursoInfoFragment ||
                destinationId == R.id.CursoAdsFragment ||
                destinationId == R.id.CursoTpgFragment ||
                destinationId == R.id.CursoAdmSubConFragment ||
                destinationId == R.id.CursoAgroSubConFragment ||
                destinationId == R.id.CursoAdmEjaFragment ||
                destinationId == R.id.CursoComercioFragment;
    }

    private void handleBackNavigation() {
        if (!navController.popBackStack()) {
            finish();
        }
    }

    private void toggleMenuSection(LinearLayout sectionToToggle, LinearLayout sectionToHide) {
        sectionToToggle.setVisibility(
                sectionToToggle.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE
        );
        sectionToHide.setVisibility(View.GONE);
    }

    private void setupMenuItems(View customMenuView) {
        int[] menuItems = {
                R.id.home_item, R.id.tecnico_integrado, R.id.tecnico_subsequente,
                R.id.tecnico_superior, R.id.tecnico_eja, R.id.sistemas_academicos,
                R.id.informacoes_institucionais, R.id.vagas_dos_cursos, R.id.sobre,
                R.id.projetos_ifrs, R.id.auxilio_estudantil, R.id.programa_ingresso
        };

        int[] destinations = {
                R.id.nav_home, R.id.TecnicoIntegradoFragment, R.id.TecnicoSubsequenteFragment,
                R.id.TecnicoSuperiorFragment, R.id.TecnicoEjaFragment, R.id.SistemasAcademicosFragment,
                R.id.InformacoesInstitucionaisFragment, R.id.VagasFragment, R.id.SobreFragment,
                R.id.ProjetosFragment, R.id.AuxilioFragment, R.id.IngressoFragment
        };

        for (int i = 0; i < menuItems.length; i++) {
            View menuItem = customMenuView.findViewById(menuItems[i]);
            if (menuItem != null) {
                final int destination = destinations[i];
                menuItem.setOnClickListener(v -> navigateToDestination(destination));
            }
        }
    }
    private void navigateToDestination(int destinationId) {
        if (navController.getCurrentDestination() == null ||
                navController.getCurrentDestination().getId() != destinationId) {

            drawer.closeDrawer(GravityCompat.START);

            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                navController.navigate(destinationId);
            }, 250);
        } else {
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (!navController.popBackStack()) {
                super.onBackPressed();
            }
        }
    }
}
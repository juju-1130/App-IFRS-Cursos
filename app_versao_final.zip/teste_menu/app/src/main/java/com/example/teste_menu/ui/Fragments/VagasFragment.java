package com.example.teste_menu.ui.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.example.teste_menu.R;

public class VagasFragment extends Fragment {
    public VagasFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_vagas, container, false);

        NavController navController = NavHostFragment.findNavController(this);

        TextView cursoAdmInt = view.findViewById(R.id.cursoAdministracaoInt);
        TextView cursoAgroInt = view.findViewById(R.id.cursoAgropecuariaInt);
        TextView cursoInfoInt = view.findViewById(R.id.cursoInformaticaInt);
        TextView cursoAdmCon = view.findViewById(R.id.cursoAdministracaoCon);
        TextView cursoAgroCon = view.findViewById(R.id.cursoAgropecuariaCon);
        TextView cursoProc = view.findViewById(R.id.cursoProcessos);
        TextView cursoADS = view.findViewById(R.id.cursoADS);
        TextView cursoComercio = view.findViewById(R.id.cursoComercio);
        TextView cursoAdmEJA = view.findViewById(R.id.cursoAdministracaoEJA);


        cursoAdmInt.setOnClickListener(v -> navController.navigate(R.id.CursoAdmFragment));
        cursoAgroInt.setOnClickListener(v -> navController.navigate(R.id.CursoAgroFragment));
        cursoInfoInt.setOnClickListener(v -> navController.navigate(R.id.CursoInfoFragment));
        cursoAdmCon.setOnClickListener(v -> navController.navigate(R.id.CursoAdmSubConFragment));
        cursoAgroCon.setOnClickListener(v -> navController.navigate(R.id.CursoAgroSubConFragment));
        cursoProc.setOnClickListener(v -> navController.navigate(R.id.CursoTpgFragment));
        cursoADS.setOnClickListener(v -> navController.navigate(R.id.CursoAdsFragment));
        cursoComercio.setOnClickListener(v -> navController.navigate(R.id.CursoComercioFragment));
        cursoAdmEJA.setOnClickListener(v -> navController.navigate(R.id.CursoAdmEjaFragment));

        return view;
    }
}

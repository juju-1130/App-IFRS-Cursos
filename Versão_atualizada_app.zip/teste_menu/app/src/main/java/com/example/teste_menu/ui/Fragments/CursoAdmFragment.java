package com.example.teste_menu.ui.Fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.teste_menu.R;

public class CursoAdmFragment extends Fragment {

    public CursoAdmFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_tela_adm, container, false);

        view.findViewById(R.id.btnAbrirSite).setOnClickListener(v -> {
            String url = "https://ifrs.edu.br/rolante/wp-content/uploads/sites/14/2022/07/PPC-integrado-administracao-vigente-a-partir-de-2022.pdf";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });

        return view;
    }
}

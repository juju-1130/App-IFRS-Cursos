package com.example.teste_menu.ui.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.example.teste_menu.R;

public class TecnicoIntegradoFragment extends Fragment {

    public TecnicoIntegradoFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_tecnico_integrado, container, false);


        CardView cardAdm = view.findViewById(R.id.card_administracao);
        CardView cardAgro = view.findViewById(R.id.card_agropecuaria);
        CardView cardInfo = view.findViewById(R.id.card_informatica);


        NavController navController = NavHostFragment.findNavController(this);


        cardAdm.setOnClickListener(v -> navController.navigate(R.id.CursoAdmFragment));
        cardAgro.setOnClickListener(v -> navController.navigate(R.id.CursoAgroFragment));
        cardInfo.setOnClickListener(v -> navController.navigate(R.id.CursoInfoFragment));

        return view;
    }
}

package com.example.teste_menu;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawer;
    private NavigationView navigationView;
    private ActionBarDrawerToggle toggle;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);


        navigationView.removeAllViews();


        View customMenuView = LayoutInflater.from(this).inflate(R.layout.nav_custom_drawer, navigationView, false);
        navigationView.addView(customMenuView);

        NavHostFragment navHostFragment =
                (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        navController = navHostFragment.getNavController();

        setupCustomMenuExpansible(customMenuView);

        // Toggle do Drawer
        toggle = new ActionBarDrawerToggle(
                this,
                drawer,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        );
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void setupCustomMenuExpansible(View customNavView) {
        LinearLayout cursosParent = customNavView.findViewById(R.id.cursos_parent);
        LinearLayout cursosChildContainer = customNavView.findViewById(R.id.cursos_child_container);

        LinearLayout estudanteParent = customNavView.findViewById(R.id.estudante_parent);
        LinearLayout estudanteChildContainer = customNavView.findViewById(R.id.estudante_child_container);

        LinearLayout homeItem = customNavView.findViewById(R.id.home_item);
        TextView tecnicoIntegradoItem = customNavView.findViewById(R.id.tecnico_integrado);
        TextView tecnicoSubsequenteItem = customNavView.findViewById(R.id.tecnico_subsequente);
        TextView cursosSuperioresItem = customNavView.findViewById(R.id.tecnico_superior);
        TextView cursosEjaItem = customNavView.findViewById(R.id.tecnico_eja);
        TextView sistemasAcademicosItem = customNavView.findViewById(R.id.sistemas_academicos);
        TextView informacoesInstitucionaisItem = customNavView.findViewById(R.id.informacoes_institucionais);
        TextView vagasItem = customNavView.findViewById(R.id.vagas_dos_cursos);
        TextView sobreItem = customNavView.findViewById(R.id.sobre);
        TextView projetosItem = customNavView.findViewById(R.id.projetos_ifrs);
        TextView auxilioItem = customNavView.findViewById(R.id.auxilio_estudantil);
        TextView ingressoItem = customNavView.findViewById(R.id.programa_ingresso);


        if (cursosParent == null || cursosChildContainer == null ||
                estudanteParent == null || estudanteChildContainer == null ||
                homeItem == null || tecnicoIntegradoItem == null ||
                tecnicoSubsequenteItem == null || cursosSuperioresItem == null ||
                cursosEjaItem == null || sistemasAcademicosItem == null ||
                informacoesInstitucionaisItem == null || vagasItem == null ||
                sobreItem == null || projetosItem == null || auxilioItem == null ||
                ingressoItem == null) {
            return;
        }

        cursosChildContainer.setVisibility(View.GONE);
        estudanteChildContainer.setVisibility(View.GONE);

        cursosParent.setOnClickListener(v -> {
            toggleMenuSection(cursosChildContainer);
            estudanteChildContainer.setVisibility(View.GONE);
        });

        estudanteParent.setOnClickListener(v -> {
            toggleMenuSection(estudanteChildContainer);
            cursosChildContainer.setVisibility(View.GONE);
        });

        // Home
        homeItem.setOnClickListener(v -> {
            navController.navigate(R.id.nav_home);
            drawer.closeDrawer(GravityCompat.START);
        });

        // Técnico Integrado
        tecnicoIntegradoItem.setOnClickListener(v -> {
            navController.navigate(R.id.TecnicoIntegradoFragment);
            drawer.closeDrawer(GravityCompat.START);
        });

        // Técnico Subsequente
        tecnicoSubsequenteItem.setOnClickListener(v -> {
            navController.navigate(R.id.TecnicoSubsequenteFragment);
            drawer.closeDrawer(GravityCompat.START);
        });

        // Cursos Superiores
        cursosSuperioresItem.setOnClickListener(v -> {
            navController.navigate(R.id.TecnicoSuperiorFragment);
            drawer.closeDrawer(GravityCompat.START);
        });
        // Cursos Eja
        cursosEjaItem.setOnClickListener(v -> {
            navController.navigate(R.id.TecnicoEjaFragment);
            drawer.closeDrawer(GravityCompat.START);
        });
        // Sistemas academicos
        sistemasAcademicosItem.setOnClickListener(v -> {
            navController.navigate(R.id.SistemasAcademicosFragment);
            drawer.closeDrawer(GravityCompat.START);
        });
        // Informacoes institucionais
        informacoesInstitucionaisItem.setOnClickListener(v -> {
            navController.navigate(R.id.InformacoesInstitucionaisFragment);
            drawer.closeDrawer(GravityCompat.START);
        });
        // vagas
        vagasItem.setOnClickListener(v -> {
            navController.navigate(R.id.VagasFragment);
            drawer.closeDrawer(GravityCompat.START);
        });
        // sobre
        sobreItem.setOnClickListener(v -> {
            navController.navigate(R.id.SobreFragment);
            drawer.closeDrawer(GravityCompat.START);
        });
        // projetos
        projetosItem.setOnClickListener(v -> {
            navController.navigate(R.id.ProjetosFragment);
            drawer.closeDrawer(GravityCompat.START);
        });
        // auxilio
        auxilioItem.setOnClickListener(v -> {
            navController.navigate(R.id.AuxilioFragment);
            drawer.closeDrawer(GravityCompat.START);
        });
        // ingresso
        ingressoItem.setOnClickListener(v -> {
            navController.navigate(R.id.IngressoFragment);
            drawer.closeDrawer(GravityCompat.START);
        });
    }

    private void toggleMenuSection(LinearLayout childContainer) {
        childContainer.setVisibility(
                childContainer.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE
        );
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
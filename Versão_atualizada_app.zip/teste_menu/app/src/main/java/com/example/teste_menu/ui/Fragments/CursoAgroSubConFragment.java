package com.example.teste_menu.ui.Fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.teste_menu.R;

public class CursoAgroSubConFragment extends Fragment {

    public CursoAgroSubConFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_tela_agro_sub_con, container, false);

        view.findViewById(R.id.btnAbrirSite).setOnClickListener(v -> {
            String url = "https://ifrs.edu.br/rolante/wp-content/uploads/sites/14/2020/02/PPC_Agropecu%C3%A1ria_Conc-Subs_Rolante.pdf";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });

        return view;
    }
}
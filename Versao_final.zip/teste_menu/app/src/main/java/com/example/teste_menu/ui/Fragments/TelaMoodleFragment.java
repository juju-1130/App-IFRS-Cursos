package com.example.teste_menu.ui.Fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.teste_menu.R;

public class TelaMoodleFragment extends Fragment {

    public TelaMoodleFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_tela_moodle, container, false);


        view.findViewById(R.id.btn_acessar_moodle).setOnClickListener(v -> {
            String url = "https://presencial.ifrs.edu.br/login/index.php";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });
        view.findViewById(R.id.link_ifrs_moodle).setOnClickListener(v -> {
            String url = "https://youtu.be/OtNjxmLpYkM";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });

        return view;
    }
}
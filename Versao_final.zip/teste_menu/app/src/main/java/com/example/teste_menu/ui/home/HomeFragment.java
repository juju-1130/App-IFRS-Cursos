package com.example.teste_menu.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.teste_menu.CarouselAdapter;
import com.example.teste_menu.R;
import com.example.teste_menu.databinding.FragmentHomeBinding;
import com.google.android.material.tabs.TabLayoutMediator;
import java.util.Arrays;
import java.util.List;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private CarouselAdapter adapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        setupCarousel();
        setupMapClickListener();
        setupCampusClickListener();
        setupButtonConhecaListener();
        return root;
    }

    private void setupCarousel() {
        List<Integer> images = Arrays.asList(
                R.drawable.ifrs_uniao,
                R.drawable.ifrs_quadra,
                R.drawable.campus_fachada
        );

        adapter = new CarouselAdapter(images);
        binding.viewPager.setAdapter(adapter);

        new TabLayoutMediator(binding.tabLayout, binding.viewPager, (tab, position) -> {}).attach();

        // Configurações adicionais
        binding.viewPager.setOffscreenPageLimit(1);
    }

    private void setupMapClickListener() {
        binding.imageMapLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // URL do Google Maps
                String mapsUrl = "https://maps.app.goo.gl/Kyp5YPhsSnBBN3TB6";

                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(mapsUrl));

                if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
    }

    private void setupCampusClickListener() {
        binding.imageSelecaoLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100)
                        .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(100));

                String editaisUrl = "https://ifrs.edu.br/rolante/editais/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(editaisUrl));

                if (intent.resolveActivity(requireActivity().getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    Toast.makeText(requireContext(), "Navegador não encontrado", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setupButtonConhecaListener() {
        binding.buttonConheca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100)
                        .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(100));

                String url = "https://ifrs.edu.br/rolante/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));


                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);

                try {
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(requireContext(),
                            "Não foi possível abrir o navegador",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
package com.example.teste_menu;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.ActionBarDrawerToggle;  // <- Import necessário
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawer;
    private NavigationView navigationView;
    private ActionBarDrawerToggle toggle;  // <- Declarar toggle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Configura a Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Drawer e NavigationView
        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        // Remove qualquer menu padrão do NavigationView
        navigationView.removeAllViews();

        // Infla o layout customizado manualmente e adiciona ao NavigationView
        View customMenuView = LayoutInflater.from(this).inflate(R.layout.nav_custom_drawer, navigationView, false);
        navigationView.addView(customMenuView);

        // Configura os cliques nos itens expansíveis do menu
        setupCustomMenuExpansible(customMenuView);

        // Adiciona o toggle para mostrar o ícone do menu na Toolbar
        toggle = new ActionBarDrawerToggle(
                this,
                drawer,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        );
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void setupCustomMenuExpansible(View customNavView) {
        LinearLayout cursosParent = customNavView.findViewById(R.id.cursos_parent);
        LinearLayout cursosChildContainer = customNavView.findViewById(R.id.cursos_child_container);

        LinearLayout estudanteParent = customNavView.findViewById(R.id.estudante_parent);
        LinearLayout estudanteChildContainer = customNavView.findViewById(R.id.estudante_child_container);

        // Referência ao item Home
        LinearLayout homeItem = customNavView.findViewById(R.id.home_item);

        if (cursosParent == null || cursosChildContainer == null ||
                estudanteParent == null || estudanteChildContainer == null ||
                homeItem == null) {
            return; // Evita erro se alguma view não for encontrada
        }

        // Fecha submenus ao iniciar
        cursosChildContainer.setVisibility(View.GONE);
        estudanteChildContainer.setVisibility(View.GONE);

        // Clique nos itens expansíveis
        cursosParent.setOnClickListener(v -> {
            toggleMenuSection(cursosChildContainer);
            estudanteChildContainer.setVisibility(View.GONE);
        });

        estudanteParent.setOnClickListener(v -> {
            toggleMenuSection(estudanteChildContainer);
            cursosChildContainer.setVisibility(View.GONE);
        });

        // Clique no Home
        homeItem.setOnClickListener(v -> {
            // Aqui você pode abrir uma nova activity ou fragment, se quiser
            drawer.closeDrawer(GravityCompat.START);
        });
    }

    private void toggleMenuSection(LinearLayout childContainer) {
        childContainer.setVisibility(
                childContainer.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE
        );
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
